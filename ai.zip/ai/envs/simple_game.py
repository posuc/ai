import gymnasium as gym
from gymnasium import spaces
import numpy as np

class SimpleGameEnv(gym.Env):
    def __init__(self):
        super().__init__()
        self.observation_space = spaces.Box(low=0, high=10, shape=(4,), dtype=np.float32)
        self.action_space = spaces.Discrete(3)  # 0, 1, 2
        self.reset()

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.state = np.random.uniform(0, 10, size=(4,)).astype(np.float32)
        return self.state, {}

    def step(self, action):
        reward = -abs(action - 1)
        self.state = np.random.uniform(0, 10, size=(4,)).astype(np.float32)
        done = np.random.rand() < 0.1
        truncated = False
        return self.state, reward, done, truncated, {}
